#!/bin/bash 

if command -v npm; then
echo "npm is already installed"
else 
echo "npm is missing. Time to install it!"
sudo apt-get update
sudo apt-get install -y npm
fi
npm install express


